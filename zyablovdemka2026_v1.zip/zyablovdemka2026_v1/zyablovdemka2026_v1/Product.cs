﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zyablovdemka2026_v1
{
    public class Product
    {
        public int Id { get; set; }
        public int NameId { get; set; }
        public string Article { get; set; }
        public string Name { get; set; }
        public string Supplier { get; set; }
        public int SupplierId { get; set; }
        public string Producer { get; set; }
        public int ProducerId { get; set; }
        public string Category { get; set; }
        public int CategoryId { get; set; }
        public int Discount { get; set; }
        public long Quantity { get; set; }
        public string Description { get; set; }
        public long Price { get; set; }
        public string ImagePath { get; set; }
    }
}
