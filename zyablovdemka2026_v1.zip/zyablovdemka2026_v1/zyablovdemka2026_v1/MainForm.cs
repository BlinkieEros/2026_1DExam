﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using static zyablovdemka2026_v1.LoginForm;

namespace zyablovdemka2026_v1
{
    public partial class MainForm : Form
    {
        private DB db = new DB();

        private void MainForm_Load(object sender, EventArgs e)
        {

            tabControl1.TabPages.Clear();
            tabControl1.TabPages.Add(tabProducts);
            userRole_label.Text = CurrentUser.Name;

            if (CurrentUser.Role == "manager")
                tabControl1.TabPages.Add(tabOrders);

            if (CurrentUser.Role == "admin")
            {

                tabControl1.TabPages.Add(tabOrders);
                tabControl1.TabPages.Add(tabAdmin);
            }
        }

        public MainForm()
        {
            InitializeComponent();
            LoadProducts();

        }
        private void tabAdmin_Enter(object sender, EventArgs e)
        {
            ShowAddPanel();
        }

        private void ShowAddPanel()
        {
            panelEdit.Visible = false;
            panelAdd.Visible = true;
            // Можно очистить поля, но не обязательно
        }


        private void ShowEditPanel(Product product)
        {
            // Заполняем поля текущими данными
            Earticle_textBox.Text = product.Article;
            Ename_textBox.Text = product.Name;
            Eprice_numericUpDown.Value = product.Price;
            Esupplier_comboBox.SelectedValue = product.SupplierId;
            Eproducer_comboBox.SelectedValue = product.ProducerId;
            Eproduct_category_comboBox.SelectedValue = product.CategoryId;
            Esale_numericUpDown.Value = product.Discount;
            Equantity_numericUpDown.Value = product.Quantity;
            EDesc_textBox.Text = product.Description ?? "";
            Ephoto_textBox.Text = product.ImagePath ?? "";

            // Сохраняем ID товара для UPDATE
            _editingProductId = product.Id;
            _editingNameId = product.NameId;

            // Показываем панель
            panelEdit.Visible = true;
            tabControl1.SelectedTab = tabAdmin; // переключаем на вкладку админа
            panelAdd.Visible = false;
        }


        public void LoadProducts()
        {
            flowLayoutPanel1.Controls.Clear();

            var products = db.GetProductsFromDB();

            foreach (var product in products)
            {
                var card = new ProductUC();
                card.SetData(product);
                card.OnEditRequested += ShowEditPanel;
                flowLayoutPanel1.Controls.Add(card);

            }
        }



        private int _editingProductId = -1;
        private int _editingNameId = -1;





        private void flowLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void save_button_Click(object sender, EventArgs e)
        {
            try
            {
                var db = new DB();
                var product = new Product
                {
                    Id = _editingProductId,
                    NameId = _editingNameId,
                    Article = Earticle_textBox.Text,
                    Name = Ename_textBox.Text,
                    Price = (long)Eprice_numericUpDown.Value,
                    SupplierId = (int)Esupplier_comboBox.SelectedValue,
                    ProducerId = (int)Eproducer_comboBox.SelectedValue,
                    CategoryId = (int)Eproduct_category_comboBox.SelectedValue,
                    Discount = (int)Esale_numericUpDown.Value,
                    Quantity = (long)Equantity_numericUpDown.Value,
                    Description = EDesc_textBox.Text,
                    ImagePath = Ephoto_textBox.Text
                };
                db.UpdateProduct(product);
                MessageBox.Show("Товар обновлён!");
                LoadProducts();
                ShowAddPanel(); // возвращаемся к добавлению
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка: " + ex.Message);
            }
        }

        private void Asave_button_Click(object sender, EventArgs e)
        {


            try
            {
                var db = new DB();

                // Получаем ID по названиям
                int supplierId = db.GetSupplierIdByName(Asupplier_textBox.Text);
                int producerId = db.GetProducerIdByName(Aproducer_textBox.Text);
                int categoryId = db.GetProductCategoryIdByName(Aproduct_category_textBox.Text);

                // Добавляем товар
                db.AddProduct(
                    Aarticle_textBox.Text.Trim(),
                    Aname_textBox.Text.Trim(),
                    (long)Aprice_numericUpDown.Value,
                    supplierId,    // вместо строки — ID
                    producerId,    // вместо строки — ID
                    categoryId,    // вместо строки — ID
                    (int)Asale_numericUpDown.Value,
                    (long)Aquantity_numericUpDown.Value,
                    ADesc_textBox.Text.Trim(),
                    Aphoto_textBox.Text.Trim()
                );

                MessageBox.Show("Товар добавлен!");
                LoadProducts();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка: " + ex.Message);
            }
        }

        private void Ecancel_button_Click(object sender, EventArgs e)
        {
            ShowAddPanel();
        }
    }
}
