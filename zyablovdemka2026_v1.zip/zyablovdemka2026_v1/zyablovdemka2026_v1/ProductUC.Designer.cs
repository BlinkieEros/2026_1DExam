﻿namespace zyablovdemka2026_v1
{
    partial class ProductUC
    {
        /// <summary> 
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором компонентов

        /// <summary> 
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            pictureBox1 = new PictureBox();
            panel1 = new Panel();
            edit_button = new Button();
            button1 = new Button();
            DiscPrice_lbl = new Label();
            Quantity_lbl = new Label();
            Unit_lbl = new Label();
            Price_lbl = new Label();
            Supp_lbl = new Label();
            Prod_lbl = new Label();
            Desc_lbl = new Label();
            Name_lbl = new Label();
            panel2 = new Panel();
            Sale_lbl = new Label();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            panel1.SuspendLayout();
            panel2.SuspendLayout();
            SuspendLayout();
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.picture;
            pictureBox1.InitialImage = Properties.Resources._1;
            pictureBox1.Location = new Point(3, 3);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(200, 200);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            // 
            // panel1
            // 
            panel1.BackColor = Color.Chartreuse;
            panel1.Controls.Add(edit_button);
            panel1.Controls.Add(button1);
            panel1.Controls.Add(DiscPrice_lbl);
            panel1.Controls.Add(Quantity_lbl);
            panel1.Controls.Add(Unit_lbl);
            panel1.Controls.Add(Price_lbl);
            panel1.Controls.Add(Supp_lbl);
            panel1.Controls.Add(Prod_lbl);
            panel1.Controls.Add(Desc_lbl);
            panel1.Controls.Add(Name_lbl);
            panel1.Location = new Point(209, 3);
            panel1.Name = "panel1";
            panel1.Size = new Size(538, 200);
            panel1.TabIndex = 1;
            // 
            // edit_button
            // 
            edit_button.Location = new Point(417, 164);
            edit_button.Name = "edit_button";
            edit_button.Size = new Size(109, 27);
            edit_button.TabIndex = 9;
            edit_button.Text = "Редактировать";
            edit_button.UseVisualStyleBackColor = true;
            edit_button.Click += edit_button_Click;
            // 
            // button1
            // 
            button1.BackColor = Color.Red;
            button1.Location = new Point(505, 6);
            button1.Name = "button1";
            button1.Size = new Size(30, 26);
            button1.TabIndex = 8;
            button1.Text = "X";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // DiscPrice_lbl
            // 
            DiscPrice_lbl.AutoSize = true;
            DiscPrice_lbl.Font = new Font("Times New Roman", 14F);
            DiscPrice_lbl.Location = new Point(148, 116);
            DiscPrice_lbl.Name = "DiscPrice_lbl";
            DiscPrice_lbl.Size = new Size(110, 21);
            DiscPrice_lbl.TabIndex = 7;
            DiscPrice_lbl.Text = "DiscPrice_lbl";
            // 
            // Quantity_lbl
            // 
            Quantity_lbl.AutoSize = true;
            Quantity_lbl.Font = new Font("Times New Roman", 14F);
            Quantity_lbl.Location = new Point(17, 158);
            Quantity_lbl.Name = "Quantity_lbl";
            Quantity_lbl.Size = new Size(101, 21);
            Quantity_lbl.TabIndex = 6;
            Quantity_lbl.Text = "Quantity_lbl";
            // 
            // Unit_lbl
            // 
            Unit_lbl.AutoSize = true;
            Unit_lbl.Font = new Font("Times New Roman", 14F);
            Unit_lbl.Location = new Point(17, 137);
            Unit_lbl.Name = "Unit_lbl";
            Unit_lbl.Size = new Size(204, 21);
            Unit_lbl.TabIndex = 5;
            Unit_lbl.Text = "Единица измерения: шт.";
            // 
            // Price_lbl
            // 
            Price_lbl.AutoSize = true;
            Price_lbl.Font = new Font("Times New Roman", 14F);
            Price_lbl.Location = new Point(17, 116);
            Price_lbl.Name = "Price_lbl";
            Price_lbl.Size = new Size(76, 21);
            Price_lbl.TabIndex = 4;
            Price_lbl.Text = "Price_lbl";
            // 
            // Supp_lbl
            // 
            Supp_lbl.AutoSize = true;
            Supp_lbl.Font = new Font("Times New Roman", 14F);
            Supp_lbl.Location = new Point(17, 95);
            Supp_lbl.Name = "Supp_lbl";
            Supp_lbl.Size = new Size(78, 21);
            Supp_lbl.TabIndex = 3;
            Supp_lbl.Text = "Supp_lbl";
            // 
            // Prod_lbl
            // 
            Prod_lbl.AutoSize = true;
            Prod_lbl.Font = new Font("Times New Roman", 14F);
            Prod_lbl.Location = new Point(17, 74);
            Prod_lbl.Name = "Prod_lbl";
            Prod_lbl.Size = new Size(75, 21);
            Prod_lbl.TabIndex = 2;
            Prod_lbl.Text = "Prod_lbl";
            // 
            // Desc_lbl
            // 
            Desc_lbl.BackColor = Color.Chartreuse;
            Desc_lbl.Font = new Font("Times New Roman", 14F);
            Desc_lbl.Location = new Point(17, 32);
            Desc_lbl.Name = "Desc_lbl";
            Desc_lbl.Size = new Size(380, 53);
            Desc_lbl.TabIndex = 1;
            Desc_lbl.Text = "Desc_lbl";
            // 
            // Name_lbl
            // 
            Name_lbl.AutoSize = true;
            Name_lbl.Font = new Font("Times New Roman", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 204);
            Name_lbl.Location = new Point(17, 10);
            Name_lbl.Name = "Name_lbl";
            Name_lbl.Size = new Size(88, 22);
            Name_lbl.TabIndex = 0;
            Name_lbl.Text = "Name_lbl";
            // 
            // panel2
            // 
            panel2.BackColor = Color.MediumSpringGreen;
            panel2.Controls.Add(Sale_lbl);
            panel2.Location = new Point(753, 3);
            panel2.Name = "panel2";
            panel2.Size = new Size(144, 200);
            panel2.TabIndex = 2;
            // 
            // Sale_lbl
            // 
            Sale_lbl.AutoSize = true;
            Sale_lbl.Font = new Font("Times New Roman", 20F);
            Sale_lbl.Location = new Point(20, 85);
            Sale_lbl.Name = "Sale_lbl";
            Sale_lbl.Size = new Size(105, 31);
            Sale_lbl.TabIndex = 0;
            Sale_lbl.Text = "Sale_lbl";
            Sale_lbl.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // ProductUC
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            AutoSize = true;
            AutoSizeMode = AutoSizeMode.GrowAndShrink;
            Controls.Add(panel2);
            Controls.Add(panel1);
            Controls.Add(pictureBox1);
            Name = "ProductUC";
            Size = new Size(900, 206);
            Load += ProductUC_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private PictureBox pictureBox1;
        private Panel panel1;
        private Panel panel2;
        private Label Quantity_lbl;
        private Label Unit_lbl;
        private Label Price_lbl;
        private Label Supp_lbl;
        private Label Prod_lbl;
        private Label Desc_lbl;
        private Label Name_lbl;
        private Label Sale_lbl;
        private Label DiscPrice_lbl;
        private Button button1;
        private Button edit_button;
    }
}
