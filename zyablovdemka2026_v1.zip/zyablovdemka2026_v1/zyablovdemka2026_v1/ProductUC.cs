﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static zyablovdemka2026_v1.LoginForm;

namespace zyablovdemka2026_v1
{
    public partial class ProductUC : UserControl
    {
        public Product Product { get; private set; }


        public ProductUC()
        {
            InitializeComponent();

        }


        public void SetData(Product product)
        {
            Product = product;
            Name_lbl.Text = product.Category + " | " + product.Name;

            if (product.Discount > 0)
            {
                DiscPrice_lbl.Visible = true;
                DiscPrice_lbl.ForeColor = Color.Red;
                Sale_lbl.Visible = true;
                Price_lbl.ForeColor = Color.Black;
                Price_lbl.Font = new Font(Price_lbl.Font, FontStyle.Strikeout);
            }
            else
            {
                DiscPrice_lbl.Visible = false;
                Sale_lbl.Visible = false;
                Price_lbl.ForeColor = Color.Black;
                Price_lbl.Font = new Font(Price_lbl.Font, FontStyle.Regular);
            }
            if (product.Discount > 15)
                panel2.BackColor = ColorTranslator.FromHtml("#2E8B57");
            Price_lbl.Text = $"Цена: {product.Price:C}";
            DiscPrice_lbl.Text = $"{(product.Price - (product.Price * product.Discount / 100)):C}";
            Quantity_lbl.Text = $"Количество: {product.Quantity}";
            Supp_lbl.Text = $"Поставщик: {product.Supplier}";
            Prod_lbl.Text = $"Производитель: {product.Producer}";
            Sale_lbl.Text = $"{product.Discount}%";
            Desc_lbl.Text = product.Description;
            try
            {
                if (!string.IsNullOrEmpty(product.ImagePath))
                {
                    // Ищем изображение по имени в ресурсах
                    string resourceName = Path.GetFileNameWithoutExtension(product.ImagePath);
                    var image = Properties.Resources.ResourceManager.GetObject(resourceName) as Image;
                    pictureBox1.Image = image;
                }
                else
                {
                    pictureBox1.Image = Properties.Resources.picture;
                }
            }
            catch (Exception)
            {
                pictureBox1.Image = Properties.Resources.picture;
            }
        }

        public void EnableEdit()
        {

            edit_button.Visible = true;
            button1.Visible = true;
        }


        private void button1_Click(object sender, EventArgs e)
        {

            if (MessageBox.Show("Удалить товар?", "Подтверждение", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                DB db = new DB();
                db.DeleteProduct(Product.Id);
                this.Parent?.Controls.Remove(this); // удалить карточку с панели
                MessageBox.Show("Товар успешно удалён!", "Успех!");
            }
        }
        public event Action<Product> OnEditRequested;

        private void edit_button_Click(object sender, EventArgs e)
        {
            OnEditRequested?.Invoke(Product);
        }

        private void ProductUC_Load(object sender, EventArgs e)
        {

        }
    }
}
