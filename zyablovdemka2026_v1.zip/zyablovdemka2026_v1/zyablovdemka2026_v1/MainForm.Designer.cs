﻿namespace zyablovdemka2026_v1
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            tabControl1 = new TabControl();
            tabProducts = new TabPage();
            flowLayoutPanel1 = new FlowLayoutPanel();
            tabAdmin = new TabPage();
            panelAdd = new Panel();
            Aproduct_category_textBox = new TextBox();
            Aproducer_textBox = new TextBox();
            Asupplier_textBox = new TextBox();
            Asave_button = new Button();
            panel3 = new Panel();
            label12 = new Label();
            Aphoto_textBox = new TextBox();
            label13 = new Label();
            ADesc_textBox = new TextBox();
            label14 = new Label();
            label15 = new Label();
            label16 = new Label();
            label17 = new Label();
            label18 = new Label();
            label19 = new Label();
            label20 = new Label();
            label21 = new Label();
            label22 = new Label();
            Aquantity_numericUpDown = new NumericUpDown();
            Asale_numericUpDown = new NumericUpDown();
            Aprice_numericUpDown = new NumericUpDown();
            Aname_textBox = new TextBox();
            Aarticle_textBox = new TextBox();
            panelEdit = new Panel();
            panel1 = new Panel();
            label11 = new Label();
            Ecancel_button = new Button();
            Esave_button = new Button();
            Ephoto_textBox = new TextBox();
            label10 = new Label();
            EDesc_textBox = new TextBox();
            label9 = new Label();
            label8 = new Label();
            label7 = new Label();
            label6 = new Label();
            label5 = new Label();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            Equantity_numericUpDown = new NumericUpDown();
            Esale_numericUpDown = new NumericUpDown();
            Eproduct_category_comboBox = new ComboBox();
            Eproducer_comboBox = new ComboBox();
            Esupplier_comboBox = new ComboBox();
            Eprice_numericUpDown = new NumericUpDown();
            Ename_textBox = new TextBox();
            Earticle_textBox = new TextBox();
            tabOrders = new TabPage();
            userRole_label = new Label();
            pictureBox1 = new PictureBox();
            tabControl1.SuspendLayout();
            tabProducts.SuspendLayout();
            tabAdmin.SuspendLayout();
            panelAdd.SuspendLayout();
            panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)Aquantity_numericUpDown).BeginInit();
            ((System.ComponentModel.ISupportInitialize)Asale_numericUpDown).BeginInit();
            ((System.ComponentModel.ISupportInitialize)Aprice_numericUpDown).BeginInit();
            panelEdit.SuspendLayout();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)Equantity_numericUpDown).BeginInit();
            ((System.ComponentModel.ISupportInitialize)Esale_numericUpDown).BeginInit();
            ((System.ComponentModel.ISupportInitialize)Eprice_numericUpDown).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // tabControl1
            // 
            tabControl1.Controls.Add(tabProducts);
            tabControl1.Controls.Add(tabAdmin);
            tabControl1.Controls.Add(tabOrders);
            tabControl1.Location = new Point(0, 63);
            tabControl1.Name = "tabControl1";
            tabControl1.SelectedIndex = 0;
            tabControl1.Size = new Size(943, 337);
            tabControl1.TabIndex = 0;
            // 
            // tabProducts
            // 
            tabProducts.Controls.Add(flowLayoutPanel1);
            tabProducts.Font = new Font("Times New Roman", 9F);
            tabProducts.Location = new Point(4, 24);
            tabProducts.Name = "tabProducts";
            tabProducts.Padding = new Padding(3);
            tabProducts.Size = new Size(935, 309);
            tabProducts.TabIndex = 0;
            tabProducts.Text = "Товары";
            tabProducts.UseVisualStyleBackColor = true;
            // 
            // flowLayoutPanel1
            // 
            flowLayoutPanel1.AutoScroll = true;
            flowLayoutPanel1.Dock = DockStyle.Fill;
            flowLayoutPanel1.Location = new Point(3, 3);
            flowLayoutPanel1.Name = "flowLayoutPanel1";
            flowLayoutPanel1.Size = new Size(929, 303);
            flowLayoutPanel1.TabIndex = 1;
            // 
            // tabAdmin
            // 
            tabAdmin.Controls.Add(panelAdd);
            tabAdmin.Controls.Add(panelEdit);
            tabAdmin.Font = new Font("Times New Roman", 9F);
            tabAdmin.Location = new Point(4, 24);
            tabAdmin.Name = "tabAdmin";
            tabAdmin.Padding = new Padding(3);
            tabAdmin.Size = new Size(935, 309);
            tabAdmin.TabIndex = 1;
            tabAdmin.Text = "Добавить Товар";
            tabAdmin.UseVisualStyleBackColor = true;
            // 
            // panelAdd
            // 
            panelAdd.Controls.Add(Aproduct_category_textBox);
            panelAdd.Controls.Add(Aproducer_textBox);
            panelAdd.Controls.Add(Asupplier_textBox);
            panelAdd.Controls.Add(Asave_button);
            panelAdd.Controls.Add(panel3);
            panelAdd.Controls.Add(Aphoto_textBox);
            panelAdd.Controls.Add(label13);
            panelAdd.Controls.Add(ADesc_textBox);
            panelAdd.Controls.Add(label14);
            panelAdd.Controls.Add(label15);
            panelAdd.Controls.Add(label16);
            panelAdd.Controls.Add(label17);
            panelAdd.Controls.Add(label18);
            panelAdd.Controls.Add(label19);
            panelAdd.Controls.Add(label20);
            panelAdd.Controls.Add(label21);
            panelAdd.Controls.Add(label22);
            panelAdd.Controls.Add(Aquantity_numericUpDown);
            panelAdd.Controls.Add(Asale_numericUpDown);
            panelAdd.Controls.Add(Aprice_numericUpDown);
            panelAdd.Controls.Add(Aname_textBox);
            panelAdd.Controls.Add(Aarticle_textBox);
            panelAdd.Location = new Point(0, 0);
            panelAdd.Name = "panelAdd";
            panelAdd.Size = new Size(939, 313);
            panelAdd.TabIndex = 1;
            // 
            // Aproduct_category_textBox
            // 
            Aproduct_category_textBox.Location = new Point(192, 221);
            Aproduct_category_textBox.Name = "Aproduct_category_textBox";
            Aproduct_category_textBox.Size = new Size(121, 21);
            Aproduct_category_textBox.TabIndex = 74;
            // 
            // Aproducer_textBox
            // 
            Aproducer_textBox.Location = new Point(192, 189);
            Aproducer_textBox.Name = "Aproducer_textBox";
            Aproducer_textBox.Size = new Size(121, 21);
            Aproducer_textBox.TabIndex = 73;
            // 
            // Asupplier_textBox
            // 
            Asupplier_textBox.Location = new Point(192, 162);
            Asupplier_textBox.Name = "Asupplier_textBox";
            Asupplier_textBox.Size = new Size(121, 21);
            Asupplier_textBox.TabIndex = 72;
            // 
            // Asave_button
            // 
            Asave_button.BackColor = Color.MediumSpringGreen;
            Asave_button.Font = new Font("Times New Roman", 10F);
            Asave_button.Location = new Point(721, 270);
            Asave_button.Name = "Asave_button";
            Asave_button.Size = new Size(81, 23);
            Asave_button.TabIndex = 71;
            Asave_button.Text = "Сохранить";
            Asave_button.UseVisualStyleBackColor = false;
            Asave_button.Click += Asave_button_Click;
            // 
            // panel3
            // 
            panel3.BackColor = Color.MediumSpringGreen;
            panel3.Controls.Add(label12);
            panel3.Location = new Point(0, 0);
            panel3.Name = "panel3";
            panel3.Size = new Size(934, 44);
            panel3.TabIndex = 70;
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Font = new Font("Times New Roman", 20F);
            label12.Location = new Point(5, 6);
            label12.Name = "label12";
            label12.Size = new Size(232, 31);
            label12.TabIndex = 26;
            label12.Text = "Добавление товара";
            // 
            // Aphoto_textBox
            // 
            Aphoto_textBox.Location = new Point(512, 108);
            Aphoto_textBox.Name = "Aphoto_textBox";
            Aphoto_textBox.Size = new Size(121, 21);
            Aphoto_textBox.TabIndex = 69;
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Font = new Font("Times New Roman", 14F);
            label13.Location = new Point(377, 108);
            label13.Name = "label13";
            label13.Size = new Size(129, 21);
            label13.TabIndex = 68;
            label13.Text = "Название фото";
            // 
            // ADesc_textBox
            // 
            ADesc_textBox.Location = new Point(512, 81);
            ADesc_textBox.Name = "ADesc_textBox";
            ADesc_textBox.Size = new Size(121, 21);
            ADesc_textBox.TabIndex = 67;
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Font = new Font("Times New Roman", 14F);
            label14.Location = new Point(417, 80);
            label14.Name = "label14";
            label14.Size = new Size(89, 21);
            label14.TabIndex = 66;
            label14.Text = "Описание";
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.Font = new Font("Times New Roman", 14F);
            label15.Location = new Point(44, 272);
            label15.Name = "label15";
            label15.Size = new Size(105, 21);
            label15.TabIndex = 65;
            label15.Text = "Количество";
            // 
            // label16
            // 
            label16.AutoSize = true;
            label16.Font = new Font("Times New Roman", 14F);
            label16.Location = new Point(44, 247);
            label16.Name = "label16";
            label16.Size = new Size(69, 21);
            label16.TabIndex = 64;
            label16.Text = "Скидка";
            // 
            // label17
            // 
            label17.AutoSize = true;
            label17.Font = new Font("Times New Roman", 14F);
            label17.Location = new Point(44, 220);
            label17.Name = "label17";
            label17.Size = new Size(94, 21);
            label17.TabIndex = 63;
            label17.Text = "Категория";
            // 
            // label18
            // 
            label18.AutoSize = true;
            label18.Font = new Font("Times New Roman", 14F);
            label18.Location = new Point(44, 191);
            label18.Name = "label18";
            label18.Size = new Size(133, 21);
            label18.TabIndex = 62;
            label18.Text = "Производитель";
            // 
            // label19
            // 
            label19.AutoSize = true;
            label19.Font = new Font("Times New Roman", 14F);
            label19.Location = new Point(44, 162);
            label19.Name = "label19";
            label19.Size = new Size(100, 21);
            label19.TabIndex = 61;
            label19.Text = "Поставщик";
            // 
            // label20
            // 
            label20.AutoSize = true;
            label20.Font = new Font("Times New Roman", 14F);
            label20.Location = new Point(44, 133);
            label20.Name = "label20";
            label20.Size = new Size(49, 21);
            label20.TabIndex = 60;
            label20.Text = "Цена";
            // 
            // label21
            // 
            label21.AutoSize = true;
            label21.Font = new Font("Times New Roman", 14F);
            label21.Location = new Point(44, 106);
            label21.Name = "label21";
            label21.Size = new Size(142, 21);
            label21.TabIndex = 59;
            label21.Text = "Название товара";
            // 
            // label22
            // 
            label22.AutoSize = true;
            label22.Font = new Font("Times New Roman", 14F);
            label22.Location = new Point(44, 79);
            label22.Name = "label22";
            label22.Size = new Size(77, 21);
            label22.TabIndex = 58;
            label22.Text = "Артикул";
            // 
            // Aquantity_numericUpDown
            // 
            Aquantity_numericUpDown.Location = new Point(192, 274);
            Aquantity_numericUpDown.Maximum = new decimal(new int[] { 1000000, 0, 0, 0 });
            Aquantity_numericUpDown.Name = "Aquantity_numericUpDown";
            Aquantity_numericUpDown.Size = new Size(121, 21);
            Aquantity_numericUpDown.TabIndex = 57;
            // 
            // Asale_numericUpDown
            // 
            Asale_numericUpDown.Location = new Point(192, 247);
            Asale_numericUpDown.Name = "Asale_numericUpDown";
            Asale_numericUpDown.Size = new Size(121, 21);
            Asale_numericUpDown.TabIndex = 56;
            // 
            // Aprice_numericUpDown
            // 
            Aprice_numericUpDown.Location = new Point(192, 133);
            Aprice_numericUpDown.Maximum = new decimal(new int[] { 1000000, 0, 0, 0 });
            Aprice_numericUpDown.Name = "Aprice_numericUpDown";
            Aprice_numericUpDown.Size = new Size(121, 21);
            Aprice_numericUpDown.TabIndex = 52;
            // 
            // Aname_textBox
            // 
            Aname_textBox.Location = new Point(192, 106);
            Aname_textBox.Name = "Aname_textBox";
            Aname_textBox.Size = new Size(121, 21);
            Aname_textBox.TabIndex = 51;
            // 
            // Aarticle_textBox
            // 
            Aarticle_textBox.Location = new Point(192, 79);
            Aarticle_textBox.Name = "Aarticle_textBox";
            Aarticle_textBox.Size = new Size(121, 21);
            Aarticle_textBox.TabIndex = 50;
            // 
            // panelEdit
            // 
            panelEdit.BackColor = Color.White;
            panelEdit.Controls.Add(panel1);
            panelEdit.Controls.Add(Ecancel_button);
            panelEdit.Controls.Add(Esave_button);
            panelEdit.Controls.Add(Ephoto_textBox);
            panelEdit.Controls.Add(label10);
            panelEdit.Controls.Add(EDesc_textBox);
            panelEdit.Controls.Add(label9);
            panelEdit.Controls.Add(label8);
            panelEdit.Controls.Add(label7);
            panelEdit.Controls.Add(label6);
            panelEdit.Controls.Add(label5);
            panelEdit.Controls.Add(label4);
            panelEdit.Controls.Add(label3);
            panelEdit.Controls.Add(label2);
            panelEdit.Controls.Add(label1);
            panelEdit.Controls.Add(Equantity_numericUpDown);
            panelEdit.Controls.Add(Esale_numericUpDown);
            panelEdit.Controls.Add(Eproduct_category_comboBox);
            panelEdit.Controls.Add(Eproducer_comboBox);
            panelEdit.Controls.Add(Esupplier_comboBox);
            panelEdit.Controls.Add(Eprice_numericUpDown);
            panelEdit.Controls.Add(Ename_textBox);
            panelEdit.Controls.Add(Earticle_textBox);
            panelEdit.Location = new Point(-4, 0);
            panelEdit.Name = "panelEdit";
            panelEdit.Size = new Size(943, 313);
            panelEdit.TabIndex = 0;
            // 
            // panel1
            // 
            panel1.BackColor = Color.MediumSpringGreen;
            panel1.Controls.Add(label11);
            panel1.Location = new Point(3, 3);
            panel1.Name = "panel1";
            panel1.Size = new Size(932, 47);
            panel1.TabIndex = 26;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Font = new Font("Times New Roman", 20F);
            label11.Location = new Point(5, 6);
            label11.Name = "label11";
            label11.Size = new Size(281, 31);
            label11.TabIndex = 26;
            label11.Text = "Редактирование товара";
            // 
            // Ecancel_button
            // 
            Ecancel_button.BackColor = Color.MediumSpringGreen;
            Ecancel_button.Font = new Font("Times New Roman", 10F);
            Ecancel_button.Location = new Point(807, 274);
            Ecancel_button.Name = "Ecancel_button";
            Ecancel_button.Size = new Size(81, 23);
            Ecancel_button.TabIndex = 24;
            Ecancel_button.Text = "Отмена";
            Ecancel_button.UseVisualStyleBackColor = false;
            Ecancel_button.Click += Ecancel_button_Click;
            // 
            // Esave_button
            // 
            Esave_button.BackColor = Color.MediumSpringGreen;
            Esave_button.Font = new Font("Times New Roman", 10F);
            Esave_button.Location = new Point(708, 274);
            Esave_button.Name = "Esave_button";
            Esave_button.Size = new Size(81, 23);
            Esave_button.TabIndex = 23;
            Esave_button.Text = "Сохранить";
            Esave_button.UseVisualStyleBackColor = false;
            Esave_button.Click += save_button_Click;
            // 
            // Ephoto_textBox
            // 
            Ephoto_textBox.Location = new Point(512, 91);
            Ephoto_textBox.Name = "Ephoto_textBox";
            Ephoto_textBox.Size = new Size(121, 21);
            Ephoto_textBox.TabIndex = 22;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Times New Roman", 14F);
            label10.Location = new Point(377, 91);
            label10.Name = "label10";
            label10.Size = new Size(129, 21);
            label10.TabIndex = 21;
            label10.Text = "Название фото";
            // 
            // EDesc_textBox
            // 
            EDesc_textBox.Location = new Point(512, 64);
            EDesc_textBox.Name = "EDesc_textBox";
            EDesc_textBox.Size = new Size(121, 21);
            EDesc_textBox.TabIndex = 20;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Times New Roman", 14F);
            label9.Location = new Point(417, 63);
            label9.Name = "label9";
            label9.Size = new Size(89, 21);
            label9.TabIndex = 19;
            label9.Text = "Описание";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Times New Roman", 14F);
            label8.Location = new Point(44, 255);
            label8.Name = "label8";
            label8.Size = new Size(105, 21);
            label8.TabIndex = 16;
            label8.Text = "Количество";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Times New Roman", 14F);
            label7.Location = new Point(44, 230);
            label7.Name = "label7";
            label7.Size = new Size(69, 21);
            label7.TabIndex = 15;
            label7.Text = "Скидка";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Times New Roman", 14F);
            label6.Location = new Point(44, 203);
            label6.Name = "label6";
            label6.Size = new Size(94, 21);
            label6.TabIndex = 14;
            label6.Text = "Категория";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Times New Roman", 14F);
            label5.Location = new Point(44, 174);
            label5.Name = "label5";
            label5.Size = new Size(133, 21);
            label5.TabIndex = 13;
            label5.Text = "Производитель";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Times New Roman", 14F);
            label4.Location = new Point(44, 145);
            label4.Name = "label4";
            label4.Size = new Size(100, 21);
            label4.TabIndex = 12;
            label4.Text = "Поставщик";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Times New Roman", 14F);
            label3.Location = new Point(44, 116);
            label3.Name = "label3";
            label3.Size = new Size(49, 21);
            label3.TabIndex = 11;
            label3.Text = "Цена";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Times New Roman", 14F);
            label2.Location = new Point(44, 89);
            label2.Name = "label2";
            label2.Size = new Size(142, 21);
            label2.TabIndex = 10;
            label2.Text = "Название товара";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Times New Roman", 14F);
            label1.Location = new Point(44, 62);
            label1.Name = "label1";
            label1.Size = new Size(77, 21);
            label1.TabIndex = 9;
            label1.Text = "Артикул";
            // 
            // Equantity_numericUpDown
            // 
            Equantity_numericUpDown.Location = new Point(192, 257);
            Equantity_numericUpDown.Maximum = new decimal(new int[] { 1000000, 0, 0, 0 });
            Equantity_numericUpDown.Name = "Equantity_numericUpDown";
            Equantity_numericUpDown.Size = new Size(121, 21);
            Equantity_numericUpDown.TabIndex = 8;
            // 
            // Esale_numericUpDown
            // 
            Esale_numericUpDown.Location = new Point(192, 230);
            Esale_numericUpDown.Name = "Esale_numericUpDown";
            Esale_numericUpDown.Size = new Size(121, 21);
            Esale_numericUpDown.TabIndex = 7;
            // 
            // Eproduct_category_comboBox
            // 
            Eproduct_category_comboBox.FormattingEnabled = true;
            Eproduct_category_comboBox.Items.AddRange(new object[] { "Мужская обувь", "Женская обувь" });
            Eproduct_category_comboBox.Location = new Point(192, 201);
            Eproduct_category_comboBox.Name = "Eproduct_category_comboBox";
            Eproduct_category_comboBox.Size = new Size(121, 23);
            Eproduct_category_comboBox.TabIndex = 6;
            // 
            // Eproducer_comboBox
            // 
            Eproducer_comboBox.FormattingEnabled = true;
            Eproducer_comboBox.Items.AddRange(new object[] { "Kari", "Marco Tozzi", "Poc", "Alesio Nesca", "Rieker", "CROSBY" });
            Eproducer_comboBox.Location = new Point(192, 172);
            Eproducer_comboBox.Name = "Eproducer_comboBox";
            Eproducer_comboBox.Size = new Size(121, 23);
            Eproducer_comboBox.TabIndex = 5;
            // 
            // Esupplier_comboBox
            // 
            Esupplier_comboBox.FormattingEnabled = true;
            Esupplier_comboBox.Items.AddRange(new object[] { "Kari", "Обувь для вас" });
            Esupplier_comboBox.Location = new Point(192, 143);
            Esupplier_comboBox.Name = "Esupplier_comboBox";
            Esupplier_comboBox.Size = new Size(121, 23);
            Esupplier_comboBox.TabIndex = 4;
            // 
            // Eprice_numericUpDown
            // 
            Eprice_numericUpDown.Location = new Point(192, 116);
            Eprice_numericUpDown.Maximum = new decimal(new int[] { 1000000, 0, 0, 0 });
            Eprice_numericUpDown.Name = "Eprice_numericUpDown";
            Eprice_numericUpDown.Size = new Size(121, 21);
            Eprice_numericUpDown.TabIndex = 3;
            // 
            // Ename_textBox
            // 
            Ename_textBox.Location = new Point(192, 89);
            Ename_textBox.Name = "Ename_textBox";
            Ename_textBox.Size = new Size(121, 21);
            Ename_textBox.TabIndex = 1;
            // 
            // Earticle_textBox
            // 
            Earticle_textBox.Location = new Point(192, 62);
            Earticle_textBox.Name = "Earticle_textBox";
            Earticle_textBox.Size = new Size(121, 21);
            Earticle_textBox.TabIndex = 0;
            // 
            // tabOrders
            // 
            tabOrders.Font = new Font("Times New Roman", 9F);
            tabOrders.Location = new Point(4, 24);
            tabOrders.Name = "tabOrders";
            tabOrders.Size = new Size(935, 309);
            tabOrders.TabIndex = 2;
            tabOrders.Text = "Заказы";
            tabOrders.UseVisualStyleBackColor = true;
            // 
            // userRole_label
            // 
            userRole_label.AutoSize = true;
            userRole_label.Font = new Font("Times New Roman", 12F);
            userRole_label.Location = new Point(670, 9);
            userRole_label.Name = "userRole_label";
            userRole_label.Size = new Size(165, 19);
            userRole_label.TabIndex = 1;
            userRole_label.Text = "Имя клиента ХЫХЫХ)";
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.Icon;
            pictureBox1.Location = new Point(0, -1);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(79, 61);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 2;
            pictureBox1.TabStop = false;
            // 
            // MainForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Chartreuse;
            ClientSize = new Size(943, 396);
            Controls.Add(pictureBox1);
            Controls.Add(userRole_label);
            Controls.Add(tabControl1);
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "MainForm";
            Text = "ООО \"Обувь\"";
            Load += MainForm_Load;
            tabControl1.ResumeLayout(false);
            tabProducts.ResumeLayout(false);
            tabAdmin.ResumeLayout(false);
            panelAdd.ResumeLayout(false);
            panelAdd.PerformLayout();
            panel3.ResumeLayout(false);
            panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)Aquantity_numericUpDown).EndInit();
            ((System.ComponentModel.ISupportInitialize)Asale_numericUpDown).EndInit();
            ((System.ComponentModel.ISupportInitialize)Aprice_numericUpDown).EndInit();
            panelEdit.ResumeLayout(false);
            panelEdit.PerformLayout();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)Equantity_numericUpDown).EndInit();
            ((System.ComponentModel.ISupportInitialize)Esale_numericUpDown).EndInit();
            ((System.ComponentModel.ISupportInitialize)Eprice_numericUpDown).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TabControl tabControl1;
        private TabPage tabProducts;
        private FlowLayoutPanel flowLayoutPanel1;
        private TabPage tabAdmin;
        private TabPage tabOrders;
        private Panel panelEdit;
        private TextBox Earticle_textBox;
        private ComboBox Esupplier_comboBox;
        private NumericUpDown Eprice_numericUpDown;
        private TextBox Ename_textBox;
        private ComboBox Eproducer_comboBox;
        private ComboBox Eproduct_category_comboBox;
        private NumericUpDown Equantity_numericUpDown;
        private NumericUpDown Esale_numericUpDown;
        private Label label1;
        private Label label8;
        private Label label7;
        private Label label6;
        private Label label5;
        private Label label4;
        private Label label3;
        private Label label2;
        private Label userRole_label;
        private PictureBox pictureBox1;
        private TextBox Ephoto_textBox;
        private Label label10;
        private TextBox EDesc_textBox;
        private Label label9;
        private Button Esave_button;
        private Panel panel1;
        private Label label11;
        private Button Ecancel_button;
        private Panel panelAdd;
        private Panel panel3;
        private Label label12;
        private TextBox Aphoto_textBox;
        private Label label13;
        private TextBox ADesc_textBox;
        private Label label14;
        private Label label15;
        private Label label16;
        private Label label17;
        private Label label18;
        private Label label19;
        private Label label20;
        private Label label21;
        private Label label22;
        private NumericUpDown Aquantity_numericUpDown;
        private NumericUpDown Asale_numericUpDown;
        private NumericUpDown Aprice_numericUpDown;
        private TextBox Aname_textBox;
        private TextBox Aarticle_textBox;
        private Button Asave_button;
        private TextBox Asupplier_textBox;
        private TextBox Aproduct_category_textBox;
        private TextBox Aproducer_textBox;
    }
}