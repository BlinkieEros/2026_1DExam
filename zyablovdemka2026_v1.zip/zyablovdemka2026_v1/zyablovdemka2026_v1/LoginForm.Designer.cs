﻿namespace zyablovdemka2026_v1
{
    partial class LoginForm
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(LoginForm));
            Login_textBox = new TextBox();
            Password_textBox = new TextBox();
            label1 = new Label();
            label2 = new Label();
            Login_button = new Button();
            SuspendLayout();
            // 
            // Login_textBox
            // 
            Login_textBox.Font = new Font("Times New Roman", 9F);
            Login_textBox.Location = new Point(68, 63);
            Login_textBox.Name = "Login_textBox";
            Login_textBox.Size = new Size(203, 21);
            Login_textBox.TabIndex = 0;
            // 
            // Password_textBox
            // 
            Password_textBox.Font = new Font("Times New Roman", 9F);
            Password_textBox.Location = new Point(68, 152);
            Password_textBox.Name = "Password_textBox";
            Password_textBox.PasswordChar = '*';
            Password_textBox.Size = new Size(203, 21);
            Password_textBox.TabIndex = 1;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Times New Roman", 15F);
            label1.Location = new Point(133, 38);
            label1.Name = "label1";
            label1.Size = new Size(64, 22);
            label1.TabIndex = 2;
            label1.Text = "Логин";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Times New Roman", 15F);
            label2.Location = new Point(133, 127);
            label2.Name = "label2";
            label2.Size = new Size(72, 22);
            label2.TabIndex = 3;
            label2.Text = "Пароль";
            // 
            // Login_button
            // 
            Login_button.BackColor = Color.MediumSpringGreen;
            Login_button.Font = new Font("Times New Roman", 16F);
            Login_button.Location = new Point(82, 198);
            Login_button.Name = "Login_button";
            Login_button.Size = new Size(179, 88);
            Login_button.TabIndex = 4;
            Login_button.Text = "Войти";
            Login_button.UseVisualStyleBackColor = false;
            Login_button.Click += button1_Click;
            // 
            // LoginForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(337, 311);
            Controls.Add(Login_button);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(Password_textBox);
            Controls.Add(Login_textBox);
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "LoginForm";
            Text = "Вход";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox Login_textBox;
        private TextBox Password_textBox;
        private Label label1;
        private Label label2;
        private Button Login_button;
    }
}
