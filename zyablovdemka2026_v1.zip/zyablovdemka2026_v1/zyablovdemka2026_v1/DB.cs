﻿using Npgsql;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zyablovdemka2026_v1
{
    public class DB
    {
        private string connectionString = "Host=localhost;Port=5434;Database=zyablovdemka2026_v1;Username=postgres;Password=postgres";

        public bool ValidateUser(string username, string password)
        {
            using (var connection = new NpgsqlConnection(connectionString))
            {
                connection.Open();
                string query = "SELECT COUNT(*) FROM userz WHERE user_login = @username AND user_password = @password";
                using (var command = new NpgsqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("username", username);
                    command.Parameters.AddWithValue("password", password);
                    int userCount = Convert.ToInt32(command.ExecuteScalar());
                    return userCount > 0;
                }
            }

        }

        public List<Product> GetProductsFromDB()
        {
         var products = new List<Product>();
            using (var connection = new NpgsqlConnection(connectionString))
            {
                connection.Open();
                string query = "select p.id_product, p.article_product, pn.id_product_name, pn.product_name, p.price_product, s.id_supplier, s.name_supplier, pr.id_producer, pr.name_producer, pc.id_product_category, pc.name_product_category, p.discount_product, p.quantity_product, p.description_product, p.photo_product from product p join product_name pn ON p.fk_product_name = pn.id_product_name join supplier s on p.fk_supplier = s.id_supplier join producer pr on p.fk_producer = pr.id_producer join product_category pc on p.fk_product_category = pc.id_product_category";


                using (var cmd = new NpgsqlCommand(query, connection))
                {
                    using (var reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            var product = new Product
                            {
                                Id = reader.GetInt32(reader.GetOrdinal("id_product")),
                                Article = reader.GetString(reader.GetOrdinal("article_product")),
                                Name = reader.GetString(reader.GetOrdinal("product_name")),
                                NameId = reader.GetInt32(reader.GetOrdinal("id_product_name")),
                                Supplier = reader.GetString(reader.GetOrdinal("name_supplier")),
                                SupplierId = reader.GetInt32(reader.GetOrdinal("id_supplier")),
                                Producer = reader.GetString(reader.GetOrdinal("name_producer")),
                                ProducerId = reader.GetInt32(reader.GetOrdinal("id_producer")),
                                Category = reader.GetString(reader.GetOrdinal("name_product_category")),
                                CategoryId = reader.GetInt32(reader.GetOrdinal("id_product_category")),
                                Discount = reader.GetInt32(reader.GetOrdinal("discount_product")),
                                Quantity = reader.GetInt32(reader.GetOrdinal("quantity_product")),
                                Description = reader.GetString(reader.GetOrdinal("description_product")),
                                Price = reader.GetInt64(reader.GetOrdinal("price_product")),
                                ImagePath = reader.IsDBNull("photo_product") ? "" :reader.GetString(reader.GetOrdinal("photo_product"))
                                
                            };
                            products.Add(product);
                        }
                    }
                }
            }
            return products;
        }





        public string GetUserRole(string username, string password)
        {
            using (var connection = new NpgsqlConnection(connectionString))
            {
                connection.Open();
                string query = "SELECT fk_user_role FROM userz WHERE user_login = @username AND user_password = @password";
                using (var cmd = new NpgsqlCommand(query, connection))
                {
                    cmd.Parameters.AddWithValue("username", username);
                    cmd.Parameters.AddWithValue("password", password);
                    var result = cmd.ExecuteScalar();
                    

                        return result?.ToString() ?? "guest";

                    
                }
            }
        }

        public int GetSupplierIdByName(string supplierName)
        {
            using var conn = new NpgsqlConnection(connectionString);
            conn.Open();
            using var cmd = new NpgsqlCommand("SELECT id_supplier FROM supplier WHERE name_supplier = @name", conn);
            cmd.Parameters.AddWithValue("@name", supplierName.Trim());
            var result = cmd.ExecuteScalar();
            if (result == null || result == DBNull.Value)
                throw new ArgumentException($"Поставщик '{supplierName}' не найден.");
            return (int)result;
        }

        public int GetProducerIdByName(string producerName)
        {
            using var conn = new NpgsqlConnection(connectionString);
            conn.Open();
            using var cmd = new NpgsqlCommand("SELECT id_producer FROM producer WHERE name_producer = @name", conn);
            cmd.Parameters.AddWithValue("@name", producerName.Trim());
            var result = cmd.ExecuteScalar();
            if (result == null || result == DBNull.Value)
                throw new ArgumentException($"Производитель '{producerName}' не найден.");
            return (int)result;
        }

        public int GetProductCategoryIdByName(string categoryName)
        {
            using var conn = new NpgsqlConnection(connectionString);
            conn.Open();
            using var cmd = new NpgsqlCommand("SELECT id_product_category FROM product_category WHERE name_product_category = @name", conn);
            cmd.Parameters.AddWithValue("@name", categoryName.Trim());
            var result = cmd.ExecuteScalar();
            if (result == null || result == DBNull.Value)
                throw new ArgumentException($"Категория '{categoryName}' не найдена.");
            return (int)result;
        }




        public void UpdateProduct(Product product)
        {
            using var conn = new NpgsqlConnection(connectionString);
            conn.Open();

            // Сначала обновим название (если нужно)
            using var cmdName = new NpgsqlCommand(
                "UPDATE product_name SET product_name = @name WHERE id_product_name = @nameId", conn);
            cmdName.Parameters.AddWithValue("@name", product.Name);
            cmdName.Parameters.AddWithValue("@nameId", product.NameId); // ← нужно добавить NameId в класс Product!
            cmdName.ExecuteNonQuery();

            // Теперь обновим сам товар
            using var cmd = new NpgsqlCommand(@"
        UPDATE product 
        SET article_product = @article,
            price_product = @price,
            fk_supplier = @supplier,
            fk_producer = @producer,
            fk_product_category = @category,
            discount_product = @discount,
            quantity_product = @quantity,
            photo_product = @photo
        WHERE id_product = @id", conn);

            cmd.Parameters.AddWithValue("@id", product.Id);
            cmd.Parameters.AddWithValue("@article", product.Article);
            cmd.Parameters.AddWithValue("@price", product.Price);
            cmd.Parameters.AddWithValue("@supplier", product.SupplierId);
            cmd.Parameters.AddWithValue("@producer", product.ProducerId);
            cmd.Parameters.AddWithValue("@category", product.CategoryId);
            cmd.Parameters.AddWithValue("@discount", product.Discount);
            cmd.Parameters.AddWithValue("@quantity", product.Quantity);
            cmd.Parameters.AddWithValue("@photo", product.ImagePath);

            cmd.ExecuteNonQuery();
        }

        



        public string GetUserName(string username, string password)
        {
            using (var connection = new NpgsqlConnection(connectionString))
            {
                connection.Open();
                string query = "SELECT user_name FROM userz WHERE user_login = @username AND user_password = @password";
                using (var cmd = new NpgsqlCommand(query, connection))
                {
                    cmd.Parameters.AddWithValue("username", username);
                    cmd.Parameters.AddWithValue("password", password);
                    var result = cmd.ExecuteScalar();


                    return result?.ToString() ?? "безымянный.";


                }
            }
        }

        public void AddProduct(string article, string name, long price, int supplierId, int producerId, int categoryId,
    int discount, long quantity, string description = null, string photoName = null)
        {
            using var conn = new NpgsqlConnection(connectionString);
            conn.Open();

            // 1. Проверяем, существует ли такое название, и получаем его ID
            int nameId;
            using (var checkCmd = new NpgsqlCommand(@"
        SELECT id_product_name FROM product_name WHERE product_name = @name", conn))
            {
                checkCmd.Parameters.AddWithValue("@name", name.Trim());
                var result = checkCmd.ExecuteScalar();
                if (result != null && result != DBNull.Value)
                {
                    nameId = (int)result;
                }
                else
                {
                    // Название не найдено — вставляем новое
                    using var insertCmd = new NpgsqlCommand(@"
                INSERT INTO product_name (product_name) 
                VALUES (@name) RETURNING id_product_name", conn);
                    insertCmd.Parameters.AddWithValue("@name", name.Trim());
                    nameId = (int)insertCmd.ExecuteScalar();
                }
            }

            // 2. Вставляем сам товар
            using var cmd = new NpgsqlCommand(@"
        INSERT INTO product (
            article_product, fk_product_name, price_product, fk_supplier, fk_producer, fk_product_category,
            discount_product, quantity_product, description_product, photo_product
        ) 
        VALUES (@article, @nameId, @price, @supplier, @producer, @category, @discount, @quantity, @description, @photo)", conn);

            cmd.Parameters.AddWithValue("@article", article);
            cmd.Parameters.AddWithValue("@nameId", nameId);
            cmd.Parameters.AddWithValue("@price", price);
            cmd.Parameters.AddWithValue("@supplier", supplierId);
            cmd.Parameters.AddWithValue("@producer", producerId);
            cmd.Parameters.AddWithValue("@category", categoryId);
            cmd.Parameters.AddWithValue("@discount", discount);
            cmd.Parameters.AddWithValue("@quantity", quantity);
            cmd.Parameters.AddWithValue("@description", (object)description ?? DBNull.Value);
            cmd.Parameters.AddWithValue("@photo", (object)photoName ?? DBNull.Value);

            cmd.ExecuteNonQuery();
        }

        public void DeleteProduct(int id)
        {
            using var conn = new NpgsqlConnection(connectionString);
            conn.Open();
            using var cmd = new NpgsqlCommand("DELETE FROM product WHERE id_product = @id", conn);
            cmd.Parameters.AddWithValue("@id", id);
            cmd.ExecuteNonQuery();
        }




    }
}
